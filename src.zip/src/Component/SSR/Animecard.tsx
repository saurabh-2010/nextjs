import Link from "next/link";
export interface AnimeProp {
    id: number
    title: string;
    userId: number;
    body: string;
}
interface Prop {
    anime: AnimeProp;
    index: number;
}
function Animecard({ anime }: Prop) {
    return (
        <>
            <div className="card h-100" style={{ width: "100 %" }}>
                <div className="card-body">
                    <h5 className="card-title">{anime.id}</h5>
                    <h6 className="card-subtitle mb-2 text-body-secondary">{anime.title}</h6>
                    {/* <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> */}
                    <Link href={`/blogdetails/${encodeURIComponent(anime.id)}`} className="card-link">View More..</Link>
                    {/* <a href="#" className="card-link">Another link</a> */}
                </div>
            </div>
        </>
    )
}
export default Animecard;