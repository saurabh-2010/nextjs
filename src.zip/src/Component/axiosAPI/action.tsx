"use server";
import axios from "axios";

const getStaticProps = async () => {
    const options = {
        method: 'GET',
        url: 'https://api.restful-api.dev/objects'
    };

    // axios.get('https://api.restful-api.dev/objects')
    //     .then(function (response: any) {
    //         // handle success
    //         console.log(response);
    //         return response.data;
    //     })
    //     .catch(function (error: any) {
    //         // handle error
    //         console.log(error);
    //     })
    //     .finally(function () {
    //         // always executed
    //     });

    try {
        console.log('ram is')
        const response = await axios.request(options);
        return response.data;



    } catch (error) {
        console.error(error);
    }

}

export default getStaticProps;