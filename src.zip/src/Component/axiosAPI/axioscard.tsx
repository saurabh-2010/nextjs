import Link from "next/link"

export interface axiosProp {
    id: number; name: string; data: { color: string; capacity: string }
}
interface Prop {
    Element: axiosProp
}
function AxiosCard({ Element }: Prop) {
    return (
        <>
            <div className="card-body">
                <h5 className="card-title">{Element.id}</h5>
                <h6 className="card-subtitle mb-2 text-body-secondary">{Element.name}</h6>
                <p> <strong>Data</strong><br />
                    Color:- {Element.data?.color}<br />
                    Capacity:- {Element.data?.capacity}
                </p>

                <Link href={`/Axios/Put/${encodeURIComponent(7)}`} className="btn btn-success">View More..</Link>
                {/* <button type="button" onClick={() => redirectPage(7)} className="btn btn-danger">Delete</button> */}

            </div>
        </>
    )
}
export default AxiosCard;