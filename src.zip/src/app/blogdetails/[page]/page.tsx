'use client';

import React from "react";
import { useState, useEffect } from 'react';
// import { boolean } from "yup";


// import { usePathname } from 'next/navigation'
// import Link from 'next/link'

const getStaticProps = async () => {
    const res = await fetch('https://jsonplaceholder.typicode.com/posts');
    const data = await res.json();
    return data;
    // return {
    //     props: {
    //         data: data
    //     }
    // }
}
export default async function blogdetails({ params }: { params: any }) {



    const data = await getStaticProps();

    const finallyArray = data.filter((data: { id: number, title: string }) => {
        // console.log(data)
        return data.id == Number(params.page)
    })



    return (

        <>
            <div key={finallyArray[0].id}>
                {finallyArray[0].id}<br />
                {finallyArray[0].title}<br />
                {finallyArray[0].body}<br />
                <strong>User: </strong>{finallyArray[0].userId}
            </div>




            <h1>I am Blog  Details page </h1>
        </>
    )
}
// import { useRouter } from 'next/router'

// export default function Page() {
//     const router = useRouter()
//     return <p>Post: {router.query.slug}</p>
// }