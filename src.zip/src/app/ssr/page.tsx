import Animecard, { AnimeProp } from "@/Component/SSR/Animecard";
import fetchAnime from "@/Component/SSR/action";
// import {fetchAnime} from '@/Component/SSR/action';
export default async function SSR() {
    const data = await fetchAnime()
    return (
        <>
            <h2 className="text-center"> This is SSR based get data from API</h2>
            <div>
                {data.map((item: AnimeProp, index: number) => (

                    <Animecard key={item.id} anime={item} index={index} />
                ))}
            </div>
        </>
    )
}