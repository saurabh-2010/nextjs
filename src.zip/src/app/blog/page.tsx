'use client'
import { useState } from 'react';
import Link from 'next/link';
import ClientSide from '../lifecyclehook/componentWillUnmount/page';
import About from '../about/page';
// const axios = require('axios');

// console.log(axios.isCancel('something'));
type posts = {
    title: string;
    id: number
}

const getStaticProps = async () => {
    const res = await fetch("https://jsonplaceholder.typicode.com/posts");
    const data = await res.json();

    return data;
    // return {
    //     props: {
    //         data,
    //     }
    // }
}



export default async function blog() {
    // function headingtoggle() {
    //     show != show;
    // }
    // const [show, setShow] = await useState(true);
    // console.log('check show value', show)
    const data = await getStaticProps();
    return (
        <>
            <div className="container">
                <div className="row">
                    <About fname='saurabh' lname='sachan' />
                    <About fname='Virendra' lname='Kumar' />
                    <About fname='Asha ' lname='Devi' />
                    <About lname='sachan' />
                    <ClientSide></ClientSide>
                    {/* {show ? <h1 className="my-4 text-center">Blog page is run</h1> : <h1> This is not blog page</h1>}<br />
                    <button onClick={() => setShow(!show)}>Click Me !</button> */}
                    {
                        data.map((curElement: { id: number, title: string }) => {
                            // console.log('ram', curElement)
                            return (

                                <div className="col-md-4 my-3" key={curElement.id}>

                                    <div className="card h-100" style={{ width: "100 %" }}>
                                        <div className="card-body">
                                            <h5 className="card-title">{curElement.id}</h5>
                                            <h6 className="card-subtitle mb-2 text-body-secondary">{curElement.title}</h6>
                                            {/* <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> */}
                                            <Link href={`/blogdetails/${encodeURIComponent(curElement.id)}`} className="card-link">View More..</Link>
                                            {/* <a href="#" className="card-link">Another link</a> */}
                                        </div>
                                    </div>


                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </>

    );
}
