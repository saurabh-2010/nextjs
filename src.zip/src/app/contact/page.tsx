"use client";
import React from "react";
import { useFormik } from "formik";
// import { Field, Formik, Form, ErrorMessage } from "formik";
// import { useRouter } from "next/navigation";
import * as Yup from "yup";
import variable from '../../styke/contact.module.scss'
// import { toast } from "react-toastify";



interface RegistrationFormData {
  name: string;
  contactno: number;
  email: string;
  message: string;
  // password: string;
  // passwordConfirmation: string;
}

// const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}$/;
const emailRules = /^[a-zA-Z0-9._%+-]+@(gmail|yahoo)\.com$/;
const contactSchema = Yup.object().shape({
  name: Yup.string().required('Name Required !'),
  contactno: Yup.number().required('Contact Number is Required !'),
  email: Yup.string()
    .email("Invalid Email!")
    .matches(emailRules, { message: " Not valid :{" })
    .required("Email Required !"),
});

const initialValues: RegistrationFormData = {
  name: "",
  contactno: 0,
  email: "",
  message: ""
};

export default function conatct() {

  const { values, handleBlur, handleChange, handleSubmit, errors } = useFormik({
    initialValues: initialValues,
    validationSchema: contactSchema,
    onSubmit: (values) => {
      console.log('contact form values', values);
    }
  })

  // console.log('formik', formik);




  const handleRegistration = (
    values: RegistrationFormData,
    { resetForm }: any
  ) => {


    const id = new Date().getTime().toString();

    const registrationEntry = {
      id: new Date().getTime().toString(),
      ...values,
    };




    resetForm();

  };




  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-6 mx-auto">

            <form onSubmit={handleSubmit}>
              <div className="items-start  p-20">
                <div className="items-start gap-6 bg-blue-400 p-10 text-lg font-medium text-yellow-100 rounded-lg">
                  <h1 className="font-extrabold text-3xl text-center" style={{ color: variable.textRed }}>Contact US</h1>
                  <label className="flex">Name</label>
                  <div className="flex flex-col text-start">
                    <input type="text" className="form-control" value={values.name} onBlur={handleBlur} onChange={handleChange} name="name" id="name" />

                    {errors.name && <small className="text-danger">{errors.name}</small>}

                  </div>

                  <label className="flex">Contact Number</label>
                  <div className="flex flex-col text-start">
                    <input type="number" className="form-control" name="contactno" id="contactno" value={values.contactno} onBlur={handleBlur} onChange={handleChange} />
                    {errors.contactno && <small className="text-danger">{errors.contactno}</small>}

                  </div>

                  <label className="flex">Email</label>
                  <div className="flex flex-col text-start">

                    <input type="email" className="form-control" name="email" id="email" value={values.email} onBlur={handleBlur} onChange={handleChange} />
                    {errors.email && <small className="text-danger">{errors.email}</small>}

                  </div>

                  <label className="flex">Message</label>
                  <div className="flex flex-col text-start">
                    <textarea
                      name="message"
                      id="message"
                      rows={5} cols={70}
                      style={{ height: "150px" }}
                      className="h-10 rounded-md text-black p-2" value={values.message} onBlur={handleBlur} onChange={handleChange}
                    ></textarea>


                  </div>

                  <div className="flex flex-wrap justify-center mt-3 items-start gap-4">
                    <button
                      className="btn btn-primary me-3"
                      type="submit"
                    >
                      Send
                    </button>

                    <button
                      className="btn btn-success"
                      type="reset"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div >

    </>
  );
}