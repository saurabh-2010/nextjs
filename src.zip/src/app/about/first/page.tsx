import Image from "next/image";
'use client';

import React from "react";
// import { useState, useEffect } from 'react';
export default function Firstabout(props: any) {
  // const [count, setCount] = useState(0)
  // const [count2, setCount2] = useState(0)

  // useEffect(() => { console.log('use effect function fire1') }, [])
  // useEffect(() => { console.log('use effect function fire 2') }, [count])
  // useEffect(() => { console.log('use effect function fire 3') }, [count2])

  function childWillTrigger() {
    props.behaviourPassedToChild('Hi from child');
  }
  return (

    <>
      <div>
        <h1>Child Component</h1>
        <p>{props.message}</p>
        <button className="btn btn-success" onClick={childWillTrigger}>Click me to talk to parent!</button>
      </div>
    </>

    // <main className="flex min-h-screen flex-col items-center justify-between p-24">
    //   <h1>This is first about us page</h1>
    //   <button className="btn btn-primary" onClick={() => setCount(count + 1)}>Like({count})</button>
    //   <button className="btn btn-primary" onClick={() => setCount2(count2 + 1)}>Dislike({count2})</button>      
    // </main>
  );
}