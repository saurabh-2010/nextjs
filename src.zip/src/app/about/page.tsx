import Image from "next/image";
export default function About({ fname = 'Lala', lname }: { fname?: string, lname: string }) {

  // console.log('props', props);
  return (
    <>
      {/* <h1>My Name is {props.fname} {props.lname}</h1> */}
      {/* <h1>{`My Name is ${props.fname} ${props.lname}`}</h1> */}
      <h1>{`My Name is ${fname} ${lname}`}</h1>
      {/* <main className="flex min-h-screen flex-col items-center justify-between p-24">

        <h1>This is about us page</h1>
      </main> */}
    </>

  );
}