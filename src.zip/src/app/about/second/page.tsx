"use client"

import React, { useEffect, useState, useRef } from 'react';
import Firstabout from '../first/page';



export default function Secondabout() {

  //  use state hook


  const [input, setValue] = useState("");
  const [name, setName] = useState('Chris');

  const handleInput = (event: any) => {
    setValue(event.target.value);
  }

  const updateName = (event: any) => {
    event.preventDefault();
    setName(input);
    setValue("");
  }


  // use state hook close


  // use state and use effect example




  const [count, setCount] = useState(0);

  useEffect(() => {
    console.log(`useEffect: ${count}`)

    return () => {
      console.log('will unmount')
    }
  }, [count]);

  // use state and use effect example

  // use ref example


  const inputEl = useRef(null);
  const onButtonClick = () => {
    // `current` points to the mounted text input element
    inputEl.current.focus();
  };


  // use ref example


  // function switchcase example

  function switchResult(a: any) {
    switch (a) {
      case 1: return "FOO";
      case 2: return "BAR";
      case 3: return "FOOBAR";
      default: return "OK";
    }
  }
  var a = switchResult(3);


  // function switchcase example


  // function pass data parent to child component example
  let messageFromChild;

  function parentWillTakeAction(message: any) {
    alert(message);
  }
  // function pass data parent to child component example







  return (
    <>
      {/* use state hook example */}
      <div className="box">
        <h1 className='text-center text-primary'> This is usesate HOOK Example</h1> <br />
        <h1 className='mb-3'>
          Hello, <span>{name}!</span>
        </h1>

        <form className="form p-3 border-1">

          <div className="field">
            <label >Update Name</label>
            <div className="control">
              <input type="text" value={input} name="name-1" onChange={handleInput} className="form-control" />
            </div>
          </div>
          <div className="field mt-3">
            <div className="control">
              <button onClick={updateName} className="btn btn-primary">Save</button>
            </div>
          </div>
        </form>

      </div>
      {/* use state hook example */}
      <hr />
      <br />
      {/* use state , use effect hook example */}
      <div className="container">
        <h1 className='text-center text-primary'> use state , use effect hook example</h1><br />
        <h1>This page rendered <span className="count">{count}</span> times</h1><br />
        <button className="btn btn-success" onClick={() => setCount(count + 1)}>
          Click Me!
        </button>
      </div>

      {/* use state , use effect hook example */}


      {/* use ref  hook example */}

      <hr />
      <br />
      <h1 className='text-center text-primary'> use ref example</h1><br />
      <input className='form-control' ref={inputEl} type="text" /><br />
      <button className='btn btn-primary' onClick={onButtonClick}>Focus the input</button>

      {/* use ref  hook example */}


      <hr />
      <br />
      {/* function switch case example */}
      <h1 className='text-center text-primary'> function switch case example</h1><br />
      <h1>Function switch case =={a}</h1>

      {/* function switch case example */}


      {/* function switch case example */}

      <hr />
      <br />
      <div>
        <h1 className='text-center text-primary'>function pass data parent to child component example</h1><br />

        <h1>Parent Component</h1><br />
        <p>Contents of the parent component</p><br />
        <Firstabout
          message="Message from parent to child"
          behaviourPassedToChild={parentWillTakeAction}
        />
      </div>
      {/* function switch case example */}





    </>
  )


  // ReactDOM.render(<App />,
  //   document.getElementById("root"))



  // return (
  //   <main className="flex min-h-screen flex-col items-center justify-between p-24">
  //     <h1>This is Second about us page</h1>
  //   </main>
  // );
}