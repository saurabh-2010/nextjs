import React from"react";
export default function FooterComponent() {
    return (
        <React.Fragment>
            <p>This is footer component</p>
        </React.Fragment>
     
    );
  }