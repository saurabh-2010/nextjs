import React from "react";
import variables from '../../styke/footer.module.scss'
export default function footer() {
    return (
        <React.Fragment>
            <>
                <p className="text-center" style={{ color: variables.textRed }}>This is footer component</p>
            </>

        </React.Fragment>

    );
}