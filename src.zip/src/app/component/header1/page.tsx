import React from"react";
export default function HeaderComponent() {
    return (
        <React.Fragment>
<ul>
        <li>
            <a>Home</a>
        </li>
        <li>
            <a>About us</a>
        </li>
        <li>
            <a>Contact</a>
        </li>
       
      </ul>
        </React.Fragment>
      
    );
  }