import React from "react";
import Link from "next/link";
export default function header() {
    return (

        <React.Fragment>

            <nav className="navbar navbar-expand-lg bg-body-tertiary">
                <div className="container-fluid">
                    <a className="navbar-brand" href="#">Navbar</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                {/* <a className="nav-link active" aria-current="page" href="#">Home</a> */}
                                <Link className="nav-link active" href="/">
                                    Home
                                </Link>
                            </li>
                            {/* <li className="nav-item">
                                <a className="nav-link" href="#">Link</a>
                            </li> */}
                            <li className="nav-item dropdown">
                                {/* <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Dropdown
                                </a> */}
                                <Link className="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false" href="/about">
                                    About us
                                </Link>
                                <ul className="dropdown-menu">
                                    <li><Link className="dropdown-item" href="/about/first">
                                        About 1
                                    </Link>
                                        {/* <a className="dropdown-item" href="#">First</a> */}
                                    </li>
                                    <li><Link className="dropdown-item" href="/about/second">
                                        About 2
                                    </Link>
                                    </li>
                                    {/* <a className="dropdown-item" href="#">Second </a> */}
                                </ul>
                            </li>

                            <li className="nav-item dropdown">
                                <Link className="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                                    Life Cycle Hook
                                </Link>
                                <ul className="dropdown-menu">
                                    <li><Link className="dropdown-item" href="/lifecyclehook/componentDidMount">
                                        Component Did Mount
                                    </Link>
                                    </li>
                                    <li><Link className="dropdown-item" href="/lifecyclehook/componentDidUpdate">
                                        Component Did Update
                                    </Link>
                                    </li>
                                </ul>
                            </li>

                            <li className="nav-item dropdown">
                                <Link className="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false" href="#">
                                    Axios
                                </Link>
                                <ul className="dropdown-menu">
                                    <li><Link className="dropdown-item" href="/Axios/Get">
                                        Get Axios
                                    </Link>
                                    </li>
                                    <li><Link className="dropdown-item" href="/Axios/Post">
                                        Post Axios
                                    </Link>
                                    </li>
                                    <li><Link className="dropdown-item" href="/Axios/Put">
                                        PUT Axios
                                    </Link>
                                    </li>
                                </ul>
                            </li>

                            <li className="nav-item">
                                {/* <a className="nav-link disabled" aria-disabled="true">Disabled</a> */}
                                <Link className="nav-link" href="/contact">
                                    Contact
                                </Link>
                            </li>

                            <li className="nav-item">
                                {/* <a className="nav-link disabled" aria-disabled="true">Disabled</a> */}
                                <Link className="nav-link" href="/Registration">
                                    Registration
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" href="/blog">
                                    Blog
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" href="/ssr">
                                    SSR
                                </Link>
                            </li>
                        </ul>
                        <form className="d-flex" role="search">
                            <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                            <button className="btn btn-outline-success" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </nav>

            {/* <nav>
                <ul className="navigationUL">

                    <li>
                        <Link href="/">
                            Home
                        </Link>
                    </li>
                    <li>
                        <Link href="/about">
                            About us
                        </Link>
                    </li>
                    <li>
                        <Link href="/contact/1">
                            Contact
                        </Link>
                    </li>
                    <li>
                        <Link href="/blog">
                            Blog
                        </Link>
                    </li>


                </ul></nav> */}
        </React.Fragment>

    );
}