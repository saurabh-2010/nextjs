"use client";
import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
const axios = require('axios');


interface RegistrationFormData {
    name: string;
    year: number;
    price: number;
    CPUmodel: string;
    Harddisksize: number;
    // password: string;
    // passwordConfirmation: string;
}


const emailRules = /^[a-zA-Z0-9._%+-]+@(gmail|yahoo)\.com$/;
const contactSchema = Yup.object().shape({
    name: Yup.string().required('Name Required !'),
    year: Yup.number().required('Year is Required !'),
    price: Yup.number().required('Price is Required !'),
    CPUmodel: Yup.string().required('CPU model Required !'),
    Harddisksize: Yup.number().required('Hard disk Required !')

});

const initialValues: RegistrationFormData = {
    name: "",
    year: 0,
    price: 0,
    CPUmodel: "",
    Harddisksize: 1
};

// const getStaticProps = async () => {


// }

export default function axiosPOST() {

    const { values, handleBlur, handleChange, handleSubmit, errors } = useFormik({
        initialValues: initialValues,
        validationSchema: contactSchema,

        onSubmit: (values, { resetForm }: any) => {
            console.log('contact form values', values);
            const putdata = {
                "name": values.name,
                "data": {
                    "year": Number(values.year),
                    "price": Number(values.price),
                    "CPU model": values.CPUmodel,
                    "Hard disk size": values.Harddisksize + ' ' + 'TB'
                }
            }
            console.log('contact form values putdata', putdata);

            axios.post('https://api.restful-api.dev/objects', putdata)
                .then(function (response: any) {
                    // console.log('123==>', response[0].status);
                    // console.log(response.status);
                    // console.log(response);
                    if (response.status == 200) {

                        alert('data successfully send')
                        resetForm();
                    }
                })
                .catch(function (error: any) {
                    console.log(error);
                });


            // const options = {
            //     method: 'POST',
            //     url: 'https://api.restful-api.dev/objects'
            // };

            // try {
            //     const response =  axios.request(options);
            //     console.log(response.data);
            //     return response.data;

            // } catch (error) {
            //     console.error(error);
            // }
        }
    })

    // console.log('formik', formik);




    // const handleRegistration = (
    //     values: RegistrationFormData,
    //     { resetForm }: any
    // ) => {
    //     console.log('hi ram', values)


    //     const id = new Date().getTime().toString();

    //     const registrationEntry = {
    //         id: new Date().getTime().toString(),
    //         ...values,
    //     };




    //     resetForm();

    // };




    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-md-6 mx-auto">

                        <form onSubmit={handleSubmit}>
                            <div className="items-start  p-20">
                                <div className="items-start gap-6 bg-blue-400 p-10 text-lg font-medium text-yellow-100 rounded-lg">
                                    <h1 className="font-extrabold text-3xl">Axios POST Data Form</h1>
                                    <label >Name</label>
                                    <div className="flex flex-col text-start">
                                        <input type="text" className="form-control" value={values.name} onBlur={handleBlur} onChange={handleChange} name="name" id="name" />

                                        {errors.name && <small className="text-danger">{errors.name}</small>}

                                    </div>
                                    <label className="flex">Year</label>
                                    <div className="flex flex-col text-start">
                                        <input type="number" className="form-control" name="year" id="year" value={values.year} onBlur={handleBlur} onChange={handleChange} />
                                        {errors.year && <small className="text-danger">{errors.year}</small>}

                                    </div>
                                    <label className="flex">Price</label>
                                    <div className="flex flex-col text-start">
                                        <input type="number" className="form-control" name="price" id="price" value={values.price} onBlur={handleBlur} onChange={handleChange} />
                                        {errors.price && <small className="text-danger">{errors.price}</small>}

                                    </div>
                                    <label className="flex">CPU Model</label>
                                    <div className="flex flex-col text-start">

                                        <input type="text" placeholder="Enter CPU Model (Intel Core i9)" className="form-control" name="CPUmodel" id="CPUmodel" value={values.CPUmodel} onBlur={handleBlur} onChange={handleChange} />
                                        {errors.CPUmodel && <small className="text-danger">{errors.CPUmodel}</small>}

                                    </div>
                                    <label className="flex">Hard Disk Size</label>
                                    <div className="flex flex-col text-start">
                                        <input type="number" placeholder="Enter Hard Disk Size" className="form-control" name="Harddisksize" id="Harddisksize" value={values.Harddisksize} onBlur={handleBlur} onChange={handleChange} />
                                        {errors.Harddisksize && <small className="text-danger">{errors.Harddisksize}</small>}

                                    </div>
                                </div>

                                <div className="flex flex-wrap justify-center mt-3 items-start gap-4">
                                    <button
                                        className="btn btn-primary"
                                        type="submit"
                                    >
                                        Send
                                    </button>

                                    <button
                                        className="btn btn-success"
                                        type="reset"
                                    >
                                        Reset
                                    </button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div >
            </div >

        </>
    );
}