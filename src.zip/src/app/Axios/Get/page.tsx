// 'use client';
import getStaticProps from "@/Component/axiosAPI/action";
import AxiosCard, { axiosProp } from "@/Component/axiosAPI/axioscard";
import Link from "next/link";
const axios = require('axios');


// const redirectPage = async (page: number) => {
//     console.log('page', page)
//     axios.delete(`https://api.restful-api.dev/objects/${page}`)
//         .then((response: any) => {
//             console.log(`Deleted post with ID ${page}`);
//             //getStaticProps();
//             alert(`Deleted post with ID ${page}`)
//         })
//         .catch((error: any) => {
//             console.error(error);
//         });
//     // e.preventDefault()
//     // document.location.href = 'https://google.com/';
// }

export default async function Axios() {
    const apidata = await getStaticProps();

    console.log('apidata', apidata)
    return (
        <>
            <div className="container">
                <div className="row">
                    {/* {apidata == undefined ? <div className="d-flex justify-center h-100 align-center"><h1 >Loading...</h1></div> : ''} */}

                    {
                        apidata && apidata.map((currrentElement: axiosProp) => {
                            <AxiosCard key={currrentElement.id} Element={currrentElement} />
                            // <div className="col-md-4 my-3" key={curElement.id}>
                            //     <div className="card h-100" style={{ width: "100 %" }}>
                            //     </div>
                            // </div>
                        })
                    }
                </div>
            </div>
        </>
    );
}

