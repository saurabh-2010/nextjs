import { useState } from "react";

const ClientSide = () => {
    const [show, setState] = useState(true);
    return (
        <>
            {show ? <h1>My Name is Saurabh</h1> : <h1>My Name is Sachan</h1>}
            <button onClick={() => setState(!show)}>Click Me!!</button>
        </>
    )
}
export default ClientSide;