'use client'
import React from "react";



export default class Page extends React.Component {
    // constructor(props: any) {
    //     super(props);
    //     this.state = {
    //         count: 0
    //     };
    // }

    // render() {
    //     return (
    //         <>
    //             <div>
    //                 <p>You clicked {this.state.count} times</p>
    //                 <button onClick={() => this.setState({ count: this.state.count + 1 })}>
    //                     Click me
    //                 </button>
    //             </div>
    //         </>
    //     );
    // }



    //[Next]



    // constructor(props: any) {
    //     super(props);
    //     this.state = {
    //         count: 0
    //     };
    // }

    // componentDidMount() {
    //     document.title = `You clicked ${this.state.count} times`;
    // }
    // componentDidUpdate() {
    //     document.title = `You clicked ${this.state.count} times`;
    // }

    render() {
        return (
            <div>
                <h1> Component Did update</h1>
                {/* <p>You clicked {this.state.count} times</p>
                <button onClick={() => this.setState({ count: this.state.count + 1 })}>
                    Click me
                </button> */}
            </div>
        );
    }

}



