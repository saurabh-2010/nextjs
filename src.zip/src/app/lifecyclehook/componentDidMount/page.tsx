
"use client"
import React, { useState, useEffect, useReducer, useId } from 'react';
// import { useEffect, useState } from "react";

// const UseEffect = () => {

//     const [countries, setCountries] = useState<Array<any>>([]);



//     useEffect(() => {

//         const getAllCountries = async () => {

//             let allCountry = await fetch('https://restcountries.com/v3.1/all');

//             let response: Array<any> = await allCountry.json();

//             if (response) {

//                 setCountries(response);

//             }

//         }



//         getAllCountries();

//     }, []);


//     return (

//         <>

//             <div className="container">

//                 <div className="flex justify-between p-3">

//                     <div className="w-1/2 border p-4">

//                         <p className="underline underline-offset-4">API call using - useEffect</p>

//                         <ul className="h-64 overflow-scroll">

//                             {countries.map((country: any, index: number) => (

//                                 <li key={index}>{country?.name?.common}</li>

//                             ))}

//                         </ul>

//                     </div>

//                 </div>

//             </div>



//         </>

//     );

// }



// export default UseEffect;


// import React, { Component } from 'react';
// import Head from 'next/head';

// export default class Home extends Component {
//     static async getInitialProps({ req }: { req: any }) {
//         const isServer = !!req;

//         return { isServer };
//     }
//     render() {
//         return (

//             <div>
//                 {this.props.isServer ? (
//                     <p>Strona została wyrenderowana przez serwer</p>
//                 ) : (
//                     <p>Strona została wyrenderowana od razu w przeglądarce</p>
//                 )}
//             </div>
//         );
//     }
// }

export default function Secondabout() {
    // //1 Embedding Expressions in JSX(Introducing JSX)
    // const user = {
    //     firstName: 'Harper',
    //     lastName: 'Perez'
    // };
    // function formatName(user: { firstName: any; lastName: any; }) {
    //     return user.firstName + ' ' + user.lastName;
    // }



    // const element = (
    //     <h1>
    //         Hello, {formatName(user)}!
    //     </h1>
    // );

    // //   const root = ReactDOM.createRoot(document.getElementById('root'));
    // //   root.render(<h1>Hello, world!</h1>);

    // return (
    //     <>
    //         <h1>
    //             Hello, {formatName(user)}!
    //         </h1>
    //         <main className="flex min-h-screen flex-col items-center justify-between p-24">
    //             <h1>This is Second about us page</h1>
    //         </main>
    //     </>

    // );



    // ///2 Rendering an Element into the DOM [Rendering Elements]

    // const element = <h1>Hello, world</h1>;
    // return (
    //     <>
    //         {element}
    //     </>
    // )

    // ///2.1 Updating the Rendered Element  [Rendering Elements]




    // // const element = new Date().toLocaleTimeString()
    // // console.log(element)
    // const element = setInterval(new Date().toLocaleTimeString(), 1000)
    // return (
    //     <>
    //         <h1> HI this is time ={element}
    //         </h1>

    //     </>
    // )
    // // const data = tick()
    // // console.log('data', data)


    // //setInterval(return(<>{tick}</>), 1000);

    // ////3.1 Rendering a Component [Components and Props]

    // function Welcome(props: any) {
    //     return <h1>Hello, {props.name}</h1>;
    // }

    // //const root = ReactDOM.createRoot(document.getElementById('root'));
    // const element = <Welcome name="Sara" />;
    // //root.render(element);
    // return (
    //     <>
    //         {element}
    //     </>
    // )

    //////3.2 Composing Components [Components and Props]
    // function Welcome(props: any) {
    //     return <h1>Hello, {props.name}</h1>;
    // }

    // const element = `<Welcome name="Sara" />,
    //     <Welcome name="Cahal" />,
    //     <Welcome name="Edite" />`

    // // return (
    // //     <>
    // //         {element}
    // //     </>
    // // )

    // // function App() {
    // //     return (
    // //         <div>
    // //             <Welcome name="Sara" />
    // //             <Welcome name="Cahal" />
    // //             <Welcome name="Edite" />
    // //         </div>
    // //     );
    // // }

    ////3.3  Extracting Components [Components and Props]

    // function formatDate(date: any) {
    //     return date.toLocaleDateString();
    // }

    // function Comment(props: any) {
    //     return (
    //         <div className="Comment">
    //             <div className="UserInfo">
    //                 <img className="Avatar"
    //                     src={props.author.avatarUrl}
    //                     alt={props.author.name} />
    //                 <div className="UserInfo-name">
    //                     {props.author.name}
    //                 </div>
    //             </div>
    //             <div className="Comment-text">
    //                 {props.text}
    //             </div>
    //             <div className="Comment-date">
    //                 {formatDate(props.date)}
    //             </div>
    //         </div>
    //     );
    // }

    // const comment = {
    //     date: new Date(),
    //     text: 'I hope you enjoy learning React!',
    //     author: {
    //         name: 'Hello Kitty',
    //         avatarUrl: 'http://placekitten.com/g/64/64'
    //     }
    // };

    // //   const root = ReactDOM.createRoot(document.getElementById('root'));
    // //   root.render(
    // //     <Comment
    // //       date={comment.date}
    // //       text={comment.text}
    // //       author={comment.author} />
    // // );
    // return (
    //     <>
    //         <Comment
    //             date={comment.date}
    //             text={comment.text}
    //             author={comment.author} />

    //     </>
    // )

    /////3.4

    // function formatDate(date: any) {
    //     return date.toLocaleDateString();
    // }

    // function Avatar(props: any) {
    //     return (
    //         <img className="Avatar"
    //             src={props.user.avatarUrl}
    //             alt={props.user.name} />
    //     );
    // }

    // function UserInfo(props: any) {
    //     return (
    //         <div className="UserInfo">
    //             <Avatar user={props.user} />
    //             <div className="UserInfo-name">
    //                 {props.user.name}
    //             </div>
    //         </div>
    //     );
    // }

    // function Comment(props: any) {
    //     return (
    //         <div className="Comment">
    //             <UserInfo user={props.author} />
    //             <div className="Comment-text">
    //                 {props.text}
    //             </div>
    //             <div className="Comment-date">
    //                 {formatDate(props.date)}
    //             </div>
    //         </div>
    //     );
    // }

    // const comment = {
    //     date: new Date(),
    //     text: 'I hope you enjoy learning React!',
    //     author: {
    //         name: 'Hello Kitty',
    //         avatarUrl: 'http://placekitten.com/g/64/64'
    //     }
    // };

    // //   const root = ReactDOM.createRoot(document.getElementById('root'));
    // //   root.render(
    // //     <Comment
    // //       date={comment.date}
    // //       text={comment.text}
    // //       author={comment.author} />
    // //   );
    // return (
    //     <>
    //         <Comment
    //             date={comment.date}
    //             text={comment.text}
    //             author={comment.author} />
    //     </>
    // )

    ///// 5.1 [State and Lifecycle]

    // function Clock(props: any) {
    //     return (
    //         <div>
    //             <h1>Hello, world!</h1>
    //             <h2>It is {props.date.toLocaleTimeString()}.</h2>
    //         </div>
    //     );
    // }

    // function tick() {
    //     return (
    //         <>
    //             <Clock date={new Date()} />
    //         </>
    //     );
    // }

    // setInterval(tick, 1000);


    //6.1  [Handling Events]

    // function Form() {
    //     function handleSubmit(e: any) {
    //         e.preventDefault();
    //         console.log('You clicked submit.');
    //     }

    //     return (
    //         <>
    //             <form onSubmit={handleSubmit}>
    //                 <button type="submit">Submit</button>
    //             </form></>
    //     );
    // }

    /// //7.1Conditional Rendering

    // function Greeting(props: any) {
    //     const isLoggedIn = props.isLoggedIn;
    //     if (isLoggedIn) {
    //         return `UserGreeting`;
    //     }
    //     return `GuestGreeting `;
    // }

    // //const root = ReactDOM.createRoot(document.getElementById('root')); 
    // // Try changing to isLoggedIn={true}:
    // // root.render(<Greeting isLoggedIn={false} />);
    // return (
    //     <>
    //         <Greeting isLoggedIn={true} />
    //     </>
    // )

    ////7.2 Inline If with Logical && Operator

    // function Mailbox(props: any) {
    //     const unreadMessages = props.unreadMessages;
    //     return (
    //         <div>
    //             <h1>Hello!</h1>
    //             {unreadMessages.length > 0 &&
    //                 <h2>
    //                     You have {unreadMessages.length} unread messages.
    //                 </h2>
    //             }
    //         </div>
    //     );
    // }

    // const messages = ['React', 'Re: React', 'Re:Re: React'];

    // //   const root = ReactDOM.createRoot(document.getElementById('root')); 
    // //   root.render(<Mailbox unreadMessages={messages} />);

    // return (
    //     <>
    //         <Mailbox unreadMessages={messages} />
    //     </>
    // )

    //7.3  Preventing Component from Rendering

    // function WarningBanner(props: any) {
    //     if (!props.warn) {
    //         return null;
    //     }

    //     return (
    //         <div className="warning">
    //             Warning!
    //         </div>
    //     );
    // }

    // class Page extends React.Component {
    //     constructor(props) {
    //         super(props);
    //         this.state = { showWarning: true };
    //         this.handleToggleClick = this.handleToggleClick.bind(this);
    //     }

    //     handleToggleClick() {
    //         this.setState(state => ({
    //             showWarning: !state.showWarning
    //         }));
    //     }

    //     render() {
    //         return (
    //             <div>
    //                 <WarningBanner warn={this.state.showWarning} />
    //                 <button onClick={this.handleToggleClick}>
    //                     {this.state.showWarning ? 'Hide' : 'Show'}
    //                 </button>
    //             </div>
    //         );
    //     }
    // }

    // const root = ReactDOM.createRoot(document.getElementById('root'));
    // root.render(<Page />);

    //////8.1  [Lists and Keys

    // function NumberList(props: any) {
    //     const numbers = props.numbers;
    //     const listItems = numbers.map((number: any) =>
    //         <li>{number}</li>
    //     );
    //     return (
    //         <ul>{listItems}</ul>
    //     );
    // }

    // const numbers = [1, 2, 3, 4, 5];
    // //   const root = ReactDOM.createRoot(document.getElementById('root'));
    // //   root.render(<NumberList numbers={numbers} />);
    // return (
    //     <>
    //         <NumberList numbers={numbers} />
    //     </>
    // )

    //// 11 []

    // function Dialog(props:any) {
    //     return (
    //       <>
    //       <div color="blue">
    //         <h1 className="Dialog-title">
    //           {props.title}
    //         </h1>
    //         <p className="Dialog-message">
    //           {props.message}
    //         </p>
    //         {props.children}
    //       </div>
    //       </>
    //     );
    //   }

    //   class SignUpDialog extends React.Component {
    //     constructor(props) {
    //       super(props);
    //       this.handleChange = this.handleChange.bind(this);
    //       this.handleSignUp = this.handleSignUp.bind(this);
    //       this.state = {login: ''};
    //     }

    //     render() {
    //       return (
    //         <Dialog title="Mars Exploration Program"
    //                 message="How should we refer to you?">
    //           <input value={this.state.login}
    //                  onChange={this.handleChange} />
    //           <button onClick={this.handleSignUp}>
    //             Sign Me Up!
    //           </button>
    //         </Dialog>
    //       );
    //     }

    //     handleChange(e) {
    //       this.setState({login: e.target.value});
    //     }

    //     handleSignUp() {
    //       alert(`Welcome aboard, ${this.state.login}!`);
    //     }
    //   }







    //////Hooks






    // function Example() {
    //     // Declare a new state variable, which we'll call "count"
    //     const [count, setCount] = useState(0);

    //     return (
    //         <>
    //             <div>
    //                 <p>You clicked {count} times</p>
    //                 <button onClick={() => setCount(count + 1)}>
    //                     Click me
    //                 </button>
    //             </div>
    //         </>
    //     );
    // }

    // [2]

    // function Example() {
    //     // Declare a new state variable, which we'll call "count"
    //     const [count, setCount] = useState(0);

    //     return (
    //         <div>
    //             <p>You clicked {count} times</p>
    //             <button onClick={() => setCount(count + 1)}>
    //                 Click me
    //             </button>
    //         </div>
    //     );
    // }


    ///[3]

    // function Example() {
    //     const [count, setCount] = useState(0);

    //     // Similar to componentDidMount and componentDidUpdate:
    //     useEffect(() => {
    //         // Update the document title using the browser API
    //         document.title = `You clicked ${count} times`;
    //     });

    //     return (
    //         <div>
    //             <p>You clicked {count} times</p>
    //             <button onClick={() => setCount(count + 1)}>
    //                 Click me
    //             </button>
    //         </div>
    //     );
    // }


    // [6]


    // function FriendListItem(props) {
    //     const [isOnline, setIsOnline] = useState(null);
    //     useEffect(() => {
    //         function handleStatusChange(status) {
    //             setIsOnline(status.isOnline);
    //         }
    //         ChatAPI.subscribeToFriendStatus(props.friend.id, handleStatusChange);
    //         return () => {
    //             ChatAPI.unsubscribeFromFriendStatus(props.friend.id, handleStatusChange);
    //         };
    //     });

    //     return (
    //         <li style={{ color: isOnline ? 'green' : 'black' }}>
    //             {props.friend.name}
    //         </li>
    //     );
    // }

    // [6.2]

    // const friendList = [
    //     { id: 1, name: 'Phoebe' },
    //     { id: 2, name: 'Rachel' },
    //     { id: 3, name: 'Ross' },
    //   ];

    //   function ChatRecipientPicker() {
    //     const [recipientID, setRecipientID] = useState(1);
    //     const isRecipientOnline = useFriendStatus(recipientID);

    //     return (
    //       <>
    //         <Circle color={isRecipientOnline ? 'green' : 'red'} />
    //         <select
    //           value={recipientID}
    //           onChange={e => setRecipientID(Number(e.target.value))}
    //         >
    //           {friendList.map(friend => (
    //             <option key={friend.id} value={friend.id}>
    //               {friend.name}
    //             </option>
    //           ))}
    //         </select>
    //       </>
    //     );
    //   }



    // [[1111]]


    // function Counter({ initialCount }) {
    //     const [count, setCount] = useState(initialCount);
    //     return (
    //         <>
    //             Count: {count}
    //             <button onClick={() => setCount(initialCount)}>Reset</button>
    //             <button onClick={() => setCount(prevCount => prevCount - 1)}>-</button>
    //             <button onClick={() => setCount(prevCount => prevCount + 1)}>+</button>
    //         </>
    //     );
    // }

    // [Next]

    // const initialState = { count: 0 };

    // function reducer(state: any, action: any) {
    //     switch (action.type) {
    //         case 'increment':
    //             return { count: state.count + 1 };
    //         case 'decrement':
    //             return { count: state.count - 1 };
    //         default:
    //             throw new Error();
    //     }
    // }

    // function Counter() {
    //     const [state, dispatch] = useReducer(reducer, initialState);
    //     return (
    //         <>
    //             <h1>useReducer</h1>
    //             Count: {state.count}
    //             <button onClick={() => dispatch({ type: 'decrement' })}>-</button>
    //             <button onClick={() => dispatch({ type: 'increment' })}>+</button>
    //         </>
    //     );
    // }



    //[;Next]


    // function NameFields() {
    //     const id = useId();
    //     return (
    //         <div>
    //             <label htmlFor={id + '-firstName'}>First Name</label>
    //             <div>
    //                 <input id={id + '-firstName'} type="text" />
    //             </div>
    //             <label htmlFor={id + '-lastName'}>Last Name</label>
    //             <div>
    //                 <input id={id + '-lastName'} type="text" />
    //             </div>
    //         </div>
    //     );
    // }




}

